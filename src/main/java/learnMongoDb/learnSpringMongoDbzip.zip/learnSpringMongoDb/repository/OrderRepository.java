package learnMongoDb.learnSpringMongoDb.repository;

import learnMongoDb.learnSpringMongoDb.entity.Order;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrderRepository extends MongoRepository<Order, String> {

    @Query("{ 'status': ?0, 'totalPrice': { $gte: ?1 } }")
    List<Order> findOrdersByStatusAndPrice(String status, double minPrice);

    List<Order> findByAddressCity(String city);

    @Query(value = "{'address.city': ?0 }", fields = "{'_id':1, 'quantity':1}")
    List<Order> findbyCity(String city);

    List<Order> findByUserId(String userId);

    /**
     * Returns true when at least one order exists for the given userId.
     * Used by DatabaseSeeder to skip re-seeding demo orders on restart.
     */
    boolean existsByUserId(String userId);
}